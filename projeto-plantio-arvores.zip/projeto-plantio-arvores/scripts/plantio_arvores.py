def plantar_arvores():
    # Código para plantar árvores
    pass

if __name__ == "__main__":
    plantar_arvores()
