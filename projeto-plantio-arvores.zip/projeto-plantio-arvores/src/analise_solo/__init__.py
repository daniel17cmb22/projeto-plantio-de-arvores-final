# Inicialize o módulo de análise de solo
