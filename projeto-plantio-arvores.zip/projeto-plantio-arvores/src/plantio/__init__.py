# Inicialize o módulo de plantio
