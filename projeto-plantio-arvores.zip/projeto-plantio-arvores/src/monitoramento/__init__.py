# Inicialize o módulo de monitoramento
